Welcome to my final project!

In essence, I wanted to create a web application that functions similarly to populat chat services such as Slack, Microsoft Teams, or Discord. 

Simply log in and follow the new group link to start a chatroom. Invite your specified users (in this case, you may need to create multiple accounts) and give the group a name. You may then click on the group's name on the left side of your screen to begin chatting. 

If you're seeing this early version, then something has gone horribly wrong and I missed the submission deadline. I promise this is just a draft. Please email me.

-Ian